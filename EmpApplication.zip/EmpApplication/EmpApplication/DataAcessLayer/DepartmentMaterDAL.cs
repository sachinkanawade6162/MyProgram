﻿using System;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;

namespace EmpApplication.DataAcessLayer
{
    class DepartmentMaterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool SaveDepartment(DepartmentMaster dept)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "insert into DepartmentMaster values('" + dept.EmpDepartment + "','" + dept.EmpDesignation + "')";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
