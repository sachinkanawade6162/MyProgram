﻿using System;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;
using System.Collections.Generic;
namespace EmpApplication.DataAcessLayer
{
    class EmpMasterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "insert into EmpMaster values(" + emp.EmpCode + ",'" + emp.EmpName + "','"+emp.EmpDob+"','"+emp.EmpGender+"','"+emp.EmpDepartment+"','"+emp.EmpDesignation+"')";
                cmd.CommandText = "SaveEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp.EmpName;
                cmd.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp.EmpDob;
                cmd.Parameters.Add("@EmpGender", SqlDbType.NVarChar).Value = emp.EmpGender;
                cmd.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp.EmpDepartment;
                cmd.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp.EmpDesignation;
                if ( sqlcon.State == ConnectionState.Closed )
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool DeleteEmployee( int EmpCode)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "Delete from EmpMaster where EmpCode=" + EmpCode + " ";
                cmd.CommandText = "DeleteEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = EmpCode;
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool UpdateEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                // cmd.CommandText = "Update EmpMaster set EmpName='" + emp.EmpName + "' where EmpCode='"+emp.EmpCode+"'";
                cmd.CommandText = "UdateEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp.EmpName;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public EmpMaster ViewEmployee(int EmpCode)
        {
            EmpMaster emp = new EmpMaster();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Select * from EmpMaster where EmpCode=" + EmpCode + " ";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    emp.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                    emp.EmpGender = dr["EmpGender"].ToString();
                    emp.EmpDepartment = dr["EmpDepartment"].ToString();
                    emp.EmpDesignation = dr["EmpDesignation"].ToString();
                }
                dr.Close();
                return emp;
            }
            catch(SqlException ex)
            {
                return emp;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public List<EmpMaster>ViewAllEmployee()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Select * from EmpMaster";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                   while( dr.Read())
                    {
                        EmpMaster emp = new EmpMaster();
                        emp.EmpCode =Convert.ToInt32(dr["EmpCode"]);
                        emp.EmpName = dr["EmpName"].ToString();
                        emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                        emp.EmpGender = dr["EmpGender"].ToString();
                        emp.EmpDepartment = dr["EmpDepartment"].ToString();
                        emp.EmpDesignation = dr["EmpDesignation"].ToString();
                        emplist.Add(emp);
                    }
                }
                dr.Close();
                return emplist;
            }
            catch(SqlException)
            {
                return emplist;
            }
        }

        public int AutoEmpCode()
        {
            int empcode = 1;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select MAX(EmpCode) from EmpMaster";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                empcode =Convert.ToInt32( cmd.ExecuteScalar());
                empcode++;
                return empcode;
            }
            catch(SqlException ex)
            {
                return empcode;
            }
            finally
            {
                sqlcon.Close();
            }
        }

    }
}
