﻿using System;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;
using System.Collections.Generic;
namespace EmpApplication.DataAcessLayer
{
    class SalaryInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public int SaveSalary(SalaryInfo sal)
        {
            int No=0;
            try
            {
                cmd.Connection = sqlcon;
                //  cmd.CommandText = "Insert into SalaryInfo values(" + sal.EmpCode + ",'" + sal.DateOfSalary + "'," + sal.Basic + "," + sal.Hra + "," + sal.Da + ")";
                cmd.CommandText = "SaveSalary";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = sal.EmpCode;
                cmd.Parameters.Add("@DateOfSalary", SqlDbType.DateTime).Value = sal.DateOfSalary;
                cmd.Parameters.Add("@Basic", SqlDbType.Decimal).Value = sal.Basic;
                cmd.Parameters.Add("@Hra", SqlDbType.Int).Value = sal.Hra;
                cmd.Parameters.Add("@Da", SqlDbType.Int).Value = sal.Da;
                cmd.Parameters.Add("@SalarySheetNo", SqlDbType.Int).Direction = ParameterDirection.Output;
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                No = Convert.ToInt32(cmd.Parameters["@SalarySheetNo"].Value);
                return No;
            }
            catch(SqlException ex)
            {
                return No;
            }
            finally
            {
                sqlcon.Close();
            }
        }
        public bool DeleteSalary(int EmpCode)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Delete from SalaryInfo where EmpCode=" + EmpCode + " ";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
        public bool UpdateSalary(SalaryInfo Sal)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Update SalaryInfo set Basic=" +Sal.Basic+ " where SalarySheetNo="+Sal.SalarySheetNo+" ";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
        public List<SalaryInfo>ViewAllSalaryInfo()
        {
            List<SalaryInfo> sallist = new List<SalaryInfo>();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from SalaryInfo";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    while(dr.Read())
                    {
                        SalaryInfo sal = new SalaryInfo();
                        sal.Basic = Convert.ToDouble(dr["Basic"]);
                        sal.Da = Convert.ToDouble(dr["Da"]);
                        sal.DateOfSalary = Convert.ToDateTime(dr["DateOfSalary"]);
                        sal.Hra = Convert.ToDouble(dr["Hra"]);
                        sal.NetSalary = Convert.ToDouble(dr["NetSalary"]);
                        sallist.Add(sal);    
                    }
                }
                dr.Close();
                return sallist;
            }
            catch(SqlException ex)
            {
                return sallist;
            }
            finally
            {
                sqlcon.Close();
            }
        }
        public int SalarySheetCount(int empcode)
        {
            int count=0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select count(*) from SalaryInfo Where EmpCode="+empcode;
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                count = Convert.ToInt32(cmd.ExecuteScalar());
                return count;
            }
            catch(SqlException ex)
            {
                return count;
            }
            finally
            {
                sqlcon.Close();
            }

        }
        public double SumOfSal(int empcode)
        {
            double sum = 0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "SumOfSalary";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = empcode;
                cmd.Parameters.Add("@sum", SqlDbType.Decimal).Direction = ParameterDirection.Output;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                sum = Convert.ToDouble(cmd.Parameters["@sum"].Value);
                return sum;
            }
            catch(SqlException ex)
            {
                return sum;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        

        
    }
}
