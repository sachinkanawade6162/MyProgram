﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using EmpApplication.DataAcessLayer;
namespace EmpApplication.DataAcessLayer
{
    class UserInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool IsValidUser(string UserName,string Password)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from UserInfo where UserName='" + UserName + "' and Password='"+ Password + "'";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
