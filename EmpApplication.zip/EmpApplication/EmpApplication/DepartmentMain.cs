﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAcessLayer;
using EmpApplication.EntityModel;
namespace EmpApplication
{
    class DepartmentMain
    {
        static void Main()
        {
            DepartmentMaterDAL deptdal = new DepartmentMaterDAL();
            Console.WriteLine("Enter 1->save Department 2->Delete Department 3->update Department 4-> View Department 5->View All Departmnet");
            int ResNo = Convert.ToInt32(Console.ReadLine());
            switch (ResNo)
            {
                case 1:
                    #region Save Dpartment
                    DepartmentMaster dept = new DepartmentMaster() { EmpDepartment = "HR", EmpDesignation = "MANAGER" };
                    if (deptdal.SaveDepartment(dept))
                    {
                        Console.WriteLine("Department Details Inserted");
                    }
                    else
                    {
                        Console.WriteLine("Error Occured");
                    }

                    #endregion
                    break;
            }

        }
    }
}
