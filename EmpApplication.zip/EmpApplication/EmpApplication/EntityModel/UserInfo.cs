﻿using System;


namespace EmpApplication.EntityModel
{
    public class UserInfo
    {
        public string UseName { get; set; }
        public string Password { get; set; }
    }
}
