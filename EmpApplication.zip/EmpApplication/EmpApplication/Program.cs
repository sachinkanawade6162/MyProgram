﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAcessLayer;
using EmpApplication.EntityModel;
namespace EmpApplication
{
    class Program
    {
        static void Main(string[] args)
        {

            EmpMasterDAL empdal = new EmpMasterDAL();
            UserInfoDAL user = new UserInfoDAL();
            bool flag=user.IsValidUser("Admin","admin123");
            if(flag)
            {
                Console.WriteLine("Enter 1->save employee 2->Delete Employee 3->update EMployee 4-> View Employee 5-> View All EMployee ");
                int ResNo = Convert.ToInt32(Console.ReadLine());
                switch (ResNo)
                {
                    case 1:
                        #region Save Employee
                        EmpMaster emp = new EmpMaster() { EmpCode = empdal.AutoEmpCode(), EmpName = "sachin", EmpDob = Convert.ToDateTime("1995-02-01"), EmpGender = "MALE", EmpDepartment = "SALES", EmpDesignation = "MANAGER" };

                        if (empdal.SaveEmployee(emp))
                        {
                            Console.WriteLine("Employee Information Insrted");
                        }
                        else
                        {
                            Console.WriteLine("error occured");
                        }
                        #endregion
                        break;
                    case 2:
                        #region Delete Employee
                        int EmpCode = 4;
                        if (empdal.DeleteEmployee(EmpCode))
                        {
                            Console.WriteLine($"Employee code {EmpCode} is Deleted");
                        }
                        else
                        {
                            Console.WriteLine("Employee is Not deleted");
                        }
                        #endregion
                        break;
                    case 3:
                        #region Update Employee
                        EmpMaster emp1 = new EmpMaster() { EmpCode = 1, EmpName = "Harsh" };

                        if (empdal.UpdateEmployee(emp1))
                        {
                            Console.WriteLine("Employee info is Updated");
                        }
                        else
                        {
                            Console.WriteLine("Employee is Not Updated");
                        }
                        #endregion
                        break;
                    case 4:
                        #region View Employee
                        EmpMaster emp2 = empdal.ViewEmployee(2);
                        if (emp2 != null)
                        {
                            Console.WriteLine($"{emp2.EmpCode}\n{emp2.EmpName}\n{emp2.EmpDob.ToString("dd-MM-yyyy")}\n{emp2.EmpGender}\n{emp2.EmpDepartment}\n{emp2.EmpDesignation}");
                        }
                        else
                        {
                            Console.WriteLine("Employee Does not exist......!");
                        }
                        #endregion
                        break;
                    case 5:
                        #region View All EMployee
                        List<EmpMaster> emplist = empdal.ViewAllEmployee();
                        if(emplist.Count>0)
                        {
                            foreach(var temp in emplist)
                            {
                                Console.WriteLine($"{temp.EmpCode}\n{temp.EmpName}\n{temp.EmpDob}\n{temp.EmpGender}\n{temp.EmpDepartment}\n{temp.EmpDesignation}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("There is no employee");
                        }
                        #endregion
                        break;

                }
            }
            else
            {
                Console.WriteLine("Incorrect UserName or Password");
            }
            
            Console.ReadLine();
        }
    }
}
