﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAcessLayer;
using EmpApplication.EntityModel;
namespace EmpApplication
{
    class SalaryMain
    {
        static void Main()
        {
            SalaryInfoDAL saldal = new SalaryInfoDAL();
            Console.WriteLine("Enter 1->save Salary 2->Delete salary 3->update salary 4-> View salary 5->View All Salary 6->no of salarySheet  7->Sum Of Salary");
            int ResNo = Convert.ToInt32(Console.ReadLine());
            switch(ResNo)
            {
                case 1:
                    #region Save salary
                    SalaryInfo sal = new SalaryInfo() { EmpCode = 2, DateOfSalary = Convert.ToDateTime("2019-02-10"), Basic = 40000, Hra = 200, Da = 100 };
                    int no = saldal.SaveSalary(sal);
                    if (no!=0)
                    {
                        Console.WriteLine("Salary Details Inserted");
                        Console.WriteLine("Salary Sheet No=" + no);
                    }
                    else
                    {
                        Console.WriteLine("Error Occured");
                    }
                    
                    #endregion
                    break;
                case 2:
                    #region
                    int EmpCode = 4;
                    if (saldal.DeleteSalary(EmpCode))
                    {
                        Console.WriteLine($"Employee {EmpCode} is Deleted");
                    }
                    else
                    {
                        Console.WriteLine("Employee is Not deleted");
                    }
                    #endregion
                    break;
                case 3:
                    #region Update SalaryInfo
                    SalaryInfo sal1 = new SalaryInfo() { Basic = 60000, SalarySheetNo=5};
                    
                    if(saldal.UpdateSalary(sal1))
                    {
                        Console.WriteLine("salary info is Updated");
                    }
                    else
                    {
                        Console.WriteLine("Salry info is Not Updated");
                    }
                    #endregion
                    break;
                case 5:
                    #region View All SalaryInfo
                    List<SalaryInfo> sallist = saldal.ViewAllSalaryInfo();
                    if(sallist.Count>0)
                    {
                        foreach(var temp in sallist)
                        {
                            Console.WriteLine($"{temp.Basic}\n{temp.Hra}\n{temp.Da}\n{temp.DateOfSalary}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No Any Salary Info");
                    }
                    #endregion
                    break;
                case 6:
                    #region Salary Sheet Count
                    int count = saldal.SalarySheetCount(3);
                    Console.WriteLine("Salary Sheet=" + count);
                    #endregion
                    break;
                case 7:
                    #region Sum Of Salary
                    double sum = saldal.SumOfSal(3);
                    Console.WriteLine("Sum of salary=" + sum);
                    #endregion
                    break;
            }
            Console.ReadLine();
        }
    }
}
