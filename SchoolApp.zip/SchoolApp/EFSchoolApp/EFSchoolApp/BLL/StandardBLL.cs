﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFSchoolApp.BLL
{
    class StandardBLL
    {
        public bool SaveStandard(Standard std)
        {
            try
            {

                using (DBSchoolEntities dbcontext = new DBSchoolEntities())
                {

                    dbcontext.Standards.Add(std);
                    dbcontext.SaveChanges();
                }
                return true;
            }catch(Exception ex)
            {
                return false;
            }
        }
        public bool DeleteStandard()
        {
            try
            {
                using (DBSchoolEntities dbcontext = new DBSchoolEntities())
                {
                    //  var s = dbcontext.Standards.First<Standard>();
                    //var s = dbcontext.Standards.Find(2);
                    var s = dbcontext.Standards.First<Standard>(x => x.StandardId == 1);
                    dbcontext.Standards.Remove(s);
                    dbcontext.SaveChanges();
                    return true;
                }
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        public bool UpdateStandard()
        {
            try
            {
                using (DBSchoolEntities dbcontext = new DBSchoolEntities())
                {
                    dbcontext.SaveChanges();
                    return true;
                }
            }
            catch(Exception ex)
            {

            }
        }
    }
}
