﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFSchoolApp.BLL;

namespace EFSchoolApp
{
    class Program
    {
        static void Main(string[] args)
        {
            StandardBLL stdbll = new StandardBLL();
            Console.WriteLine("1.Enter 2.Delete 3.Update 4.View");
            int response = Convert.ToInt32(Console.ReadLine());
            switch (response)
            {
                case 1:
                    #region Enter 
                    Standard std = new Standard()
            {
                StandardId = 2, StandardName = "IV", Description = "Junior"
            };
            if (stdbll.SaveStandard(std))
            {
                Console.WriteLine("Standard Add SucessFully");
            }
            else
            {
                Console.WriteLine("Error Occured");
            }
                    #endregion
                    break;
                case 2:
                    #region Delete
                    if(stdbll.DeleteStandard())
                    {
                        Console.WriteLine("Standard Delted");
                    }
                    else
                    {
                        Console.WriteLine("Standard Not deleted");
                    }
                    #endregion
                    break;


            }
            Console.ReadLine();
        }
    }
}
